package com.example.lebensmittelverwaltung.data.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName ="einkaeufe")
data class Einkaeufe (
    @ColumnInfo(name= "einkauf_name")
    var name: String,

    @ColumnInfo(name= "gesamtpreis")
    var gesamtpreis : Double = 0.00
        ) {


    @PrimaryKey(autoGenerate = true)
    var id: Int? = null


}