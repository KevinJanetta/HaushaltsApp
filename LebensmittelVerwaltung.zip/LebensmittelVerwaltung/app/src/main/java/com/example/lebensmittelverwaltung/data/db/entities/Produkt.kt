package com.example.lebensmittelverwaltung.data.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable
import java.util.*

@Entity(tableName ="einkaufs_produkt")

data class Produkt (
    @ColumnInfo(name= "produkt_name")
    var name: String,
    @ColumnInfo(name = "produkt_anzahl")
    var anzahl: Int,
    @ColumnInfo(name = "produkt_preis")
    var preis: Double? = 0.00,
    @ColumnInfo(name = "produkt_gekauft")
    var gekauft : Boolean? = false


) : Serializable {
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null
}