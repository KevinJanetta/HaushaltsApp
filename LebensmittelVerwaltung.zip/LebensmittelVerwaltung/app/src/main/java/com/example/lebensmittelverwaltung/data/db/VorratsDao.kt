package com.example.lebensmittelverwaltung.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.lebensmittelverwaltung.data.db.entities.ProduktVorrat


@Dao
interface VorratsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVorrat(produkt: ProduktVorrat)

    @Delete
    suspend fun deleteVorrat(produkt: ProduktVorrat)

    @Query("SELECT * FROM vorrat_produkt")
    fun getAllProdukteVorratsliste() : LiveData<List<ProduktVorrat>>
}