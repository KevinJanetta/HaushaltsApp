package com.example.lebensmittelverwaltung.ui.einkaufsliste

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDialog
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.lebensmittelverwaltung.R
import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.data.db.entities.ProduktVorrat
import kotlinx.android.synthetic.main.dialog_einkaufsliste_produkt_gekauft.*


class EinkaufslisteProduktGekauftDialog (context: Context, var produkt : Produkt?, var addDialogListener: AddDialogListener) : AppCompatDialog(context){


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_einkaufsliste_produkt_gekauft)


        tvProduktgekauftName.text = produkt?.name.toString()
        etProduktGekauftAnzahl.hint = produkt?.anzahl.toString()


        btnProduktGekauftOk.setOnClickListener {
            val name = tvProduktgekauftName.text.toString()
            val anzahl = etProduktGekauftPreis.text.toString()
            val datum = etProduktGekauftDatum.text.toString()
            val preis = etProduktGekauftPreis.text.toString().toDouble()




            if(name.isEmpty() || anzahl.isEmpty()){
                Toast.makeText(context, "Bitte fülle alle Felder aus", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val produkt = Produkt(name, anzahl.toInt(), preis)
            val produktVorrat = ProduktVorrat(name, anzahl.toInt(), datum)
            addDialogListener.onAddButtonClicked(produkt)
            addDialogListener.onAddButtonClickedVorrat(produktVorrat)
            dismiss()
        }

        btnProduktGekauftAbbrechen.setOnClickListener {
            cancel()
        }



    }

}