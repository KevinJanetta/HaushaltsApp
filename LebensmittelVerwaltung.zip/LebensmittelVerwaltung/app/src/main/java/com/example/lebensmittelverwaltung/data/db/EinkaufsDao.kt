package com.example.lebensmittelverwaltung.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.data.db.entities.ProduktVorrat

@Dao
interface EinkaufsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(produkt: Produkt)

    @Delete
    suspend fun delete(produkt: Produkt)

    @Delete
    suspend fun deleteAll(list : List<Produkt>)


    @Query("SELECT * FROM einkaufs_produkt")
    fun getAllProdukteEinkaufsliste() : LiveData<List<Produkt>>


}