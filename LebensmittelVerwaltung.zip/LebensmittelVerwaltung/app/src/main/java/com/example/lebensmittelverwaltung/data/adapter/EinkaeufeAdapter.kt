package com.example.lebensmittelverwaltung.data.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.lebensmittelverwaltung.R
import com.example.lebensmittelverwaltung.data.db.entities.Einkaeufe
import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.ui.einkaufsliste.ViewModel
import kotlinx.android.synthetic.main.einkauf_einkaeufe.view.*
import kotlinx.android.synthetic.main.einkauf_einkaeufe.view.tvEinkaeufeNameEinkauf
import kotlinx.android.synthetic.main.einkauf_einkaeufe.view.tvPreisEinkauf
import kotlinx.android.synthetic.main.produkt_einkaufsliste.view.*

class EinkaeufeAdapter (
    var einkaeufe : List<Einkaeufe>,
    private val viewModel : ViewModel,
    ) : RecyclerView.Adapter<EinkaeufeAdapter.EinkaeufeViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EinkaeufeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.einkauf_einkaeufe,parent, false)
        return EinkaeufeViewHolder(view)
    }

    override fun onBindViewHolder(holder: EinkaeufeAdapter.EinkaeufeViewHolder, position: Int) {
        val curEinkauf = einkaeufe[position]

        holder.itemView.tvEinkaeufeNameEinkauf.text = curEinkauf.name
        holder.itemView.tvPreisEinkauf.text = curEinkauf.gesamtpreis.toString()

        holder.itemView.ivdeleteEinkauf.setOnClickListener {
            viewModel.deleteEinkauf(curEinkauf)
        }
    }

    override fun getItemCount(): Int {
        return einkaeufe.size
    }




    inner class EinkaeufeViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView)


}
