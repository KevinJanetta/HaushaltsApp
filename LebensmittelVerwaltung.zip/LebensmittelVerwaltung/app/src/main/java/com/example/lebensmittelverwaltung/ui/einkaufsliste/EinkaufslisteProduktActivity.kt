package com.example.lebensmittelverwaltung.ui.einkaufsliste

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lebensmittelverwaltung.R

class EinkaufslisteProduktActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_einkaufsliste_produkt)
    }
}