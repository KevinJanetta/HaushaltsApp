package com.example.lebensmittelverwaltung.ui.einkaufsliste

import android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
import android.widget.TextView
import androidx.lifecycle.ViewModel
import com.example.lebensmittelverwaltung.data.db.entities.Einkaeufe
import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.data.db.entities.ProduktVorrat
import com.example.lebensmittelverwaltung.data.reporsitories.Repository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ViewModel (
    private val repository: Repository
        ) : ViewModel() {

        fun upsert(produkt : Produkt) = CoroutineScope(Dispatchers.Main).launch { //MVVM ShoppingList App - REPOSITORY, VIEWMODEL, VIEWMODELFACTORY - Part 3 (ca. 6:00)
            repository.upsert(produkt)
        }

        fun delete(produkt: Produkt) = CoroutineScope(Dispatchers.Main).launch {
            repository.delete(produkt)
        }

        fun getAllProdukte() = repository.getAllProdukte()

        fun deleteAll(list : List<Produkt>) = CoroutineScope(Dispatchers.Main).launch {
            repository.deleteAll(list)
        }

         fun upsertVorrat(produktVorrat: ProduktVorrat) = CoroutineScope(Dispatchers.Main).launch {
             repository.upsertVorrat(produktVorrat)
         }

        fun deleteVorrat(produktVorrat: ProduktVorrat) = CoroutineScope(Dispatchers.Main).launch {
            repository.deleteVorrat(produktVorrat)
         }

        fun getAllProdukteVorratsliste() = repository.getAllProdukteVorratsliste()


        fun upsertEinkauf(einkauf: Einkaeufe) = CoroutineScope(Dispatchers.Main).launch {
            repository.upsertEinkauf(einkauf)
        }

        fun deleteEinkauf(einkauf: Einkaeufe) = CoroutineScope(Dispatchers.Main).launch {
            repository.deleteEinkauf(einkauf)
        }

        fun getAllEinkaeufe() = repository.getAllEinkaeufe()


        fun produktGekauft(produkt: Produkt) {
            produkt.gekauft = true
        }

        fun gekauftesProduktMarkieren(produkt: Produkt, gekauft : Boolean) { //https://www.youtube.com/watch?v=BBWyXo-3JGQ&list=WL&index=100&t=3748s&ab_channel=TraversyMedia // 52:00
            if(gekauft) {
                produkt.name = produkt.name +"(Gekauft)"
            }

        }

        fun gesamtpreis(list: List<Produkt>) : Double{
            var gesamtPreis = 0.00

            for(produkt in list){
                if(produkt.gekauft!!){
                    gesamtPreis += (produkt.preis!! * produkt.anzahl)
                }
            }
            return gesamtPreis
        }


}