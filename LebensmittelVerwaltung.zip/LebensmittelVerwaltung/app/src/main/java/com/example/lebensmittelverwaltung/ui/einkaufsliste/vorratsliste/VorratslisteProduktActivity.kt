package com.example.lebensmittelverwaltung.ui.einkaufsliste.vorratsliste

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lebensmittelverwaltung.R

class VorratslisteProduktActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vorratsliste_produkt)
    }
}