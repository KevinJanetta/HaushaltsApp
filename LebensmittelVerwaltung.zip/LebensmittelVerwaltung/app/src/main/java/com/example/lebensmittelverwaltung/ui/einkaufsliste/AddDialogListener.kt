package com.example.lebensmittelverwaltung.ui.einkaufsliste

import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.data.db.entities.ProduktVorrat

interface AddDialogListener {
    fun onAddButtonClicked(produkt : Produkt)

    fun onAddButtonClickedVorrat(produktVorrat: ProduktVorrat)

    fun onAddButtonClickedEinkauf(name : String)
}