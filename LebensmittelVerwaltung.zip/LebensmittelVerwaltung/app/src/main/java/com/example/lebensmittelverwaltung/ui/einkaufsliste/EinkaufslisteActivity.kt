package com.example.lebensmittelverwaltung.ui.einkaufsliste

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.lebensmittelverwaltung.*
import com.example.lebensmittelverwaltung.data.adapter.ProduktAdapter
import com.example.lebensmittelverwaltung.data.db.EinkaufDatenbank
import com.example.lebensmittelverwaltung.data.db.entities.Einkaeufe
import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.data.db.entities.ProduktVorrat
import com.example.lebensmittelverwaltung.data.reporsitories.Repository
import com.example.lebensmittelverwaltung.ui.einkaufsliste.vorratsliste.VorratslisteActivity
import kotlinx.android.synthetic.main.activity_einkaufsliste.*
import kotlinx.android.synthetic.main.activity_einkaufsliste.btnEinkaeufe
import kotlinx.android.synthetic.main.activity_einkaufsliste.btnVorratsliste
import kotlinx.android.synthetic.main.activity_einkaufsliste.rvEinkaeufeListe
import kotlinx.android.synthetic.main.activity_einkaufsliste.tvEinkauf


class EinkaufslisteActivity : AppCompatActivity() {


    @SuppressLint("NotifyDataSetChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_einkaufsliste)

        val database = EinkaufDatenbank(this)
        val repository = Repository(database)
        val factory = ViewModelFactory(repository)


        val viewModel = ViewModelProviders.of(this, factory).get(ViewModel::class.java)

        val adapter = ProduktAdapter(listOf(), viewModel)

        rvEinkaeufeListe.layoutManager = LinearLayoutManager(this)
        rvEinkaeufeListe.adapter = adapter

        viewModel.getAllProdukte().observe(this, Observer {
            adapter.items = it
            adapter.notifyDataSetChanged()
        })

        btnProdukthinzufuegen.setOnClickListener {

            EinkaufslisteProdukthinzufuegenDialog(this,
                object : AddDialogListener{
                    override fun onAddButtonClicked(produkt: Produkt) {
                        viewModel.upsert(produkt)
                    }

                    override fun onAddButtonClickedEinkauf(name: String) {
                    }

                    override fun onAddButtonClickedVorrat(produktVorrat: ProduktVorrat) {

                    }
                }).show()

        }


        adapter.setOnItemClickListener {
            val produkt1 = it


            EinkaufslisteProduktGekauftDialog(this, produkt1, object : AddDialogListener{
                override fun onAddButtonClicked(produkt: Produkt) {
                    produkt1.preis = produkt.preis
                    viewModel.upsert(produkt1)
                }
                override fun onAddButtonClickedVorrat(produktVorrat: ProduktVorrat) {
                    viewModel.produktGekauft(produkt1)
                    viewModel.gekauftesProduktMarkieren(produkt1, produkt1.gekauft!!)
                    viewModel.upsertVorrat(produktVorrat)
                }

                override fun onAddButtonClickedEinkauf(name: String) {

                }

            }).show()
        }


        btnVorratsliste.setOnClickListener {
            Intent(this, VorratslisteActivity::class.java).also {
                startActivity(it)

            }
        }

        btnEinkaeufe.setOnClickListener {
            Intent(this, EinkaeufeActivity::class.java).also {
                startActivity(it)
            }
        }

        btnNeuerEinkauf.setOnClickListener {
            EinkaufslisteNeuerEinkaufDialog(this,
                object : AddDialogListener{
                    override fun onAddButtonClicked(produkt: Produkt) {
                    }

                    override fun onAddButtonClickedEinkauf(name: String) {
                        viewModel.deleteAll(adapter.items)
                        tvEinkauf.text = name
                    }


                    override fun onAddButtonClickedVorrat(produktVorrat: ProduktVorrat) {
                    }
                }).show()
        }

        btnEinkaufabschließen.setOnClickListener {
            val name = tvEinkauf.text.toString()
            val gesamtPreis =  viewModel.gesamtpreis(adapter.items)
            val einkauf = Einkaeufe(name, gesamtPreis)


            viewModel.upsertEinkauf(einkauf)
            viewModel.deleteAll(adapter.items)
        }





    }
}