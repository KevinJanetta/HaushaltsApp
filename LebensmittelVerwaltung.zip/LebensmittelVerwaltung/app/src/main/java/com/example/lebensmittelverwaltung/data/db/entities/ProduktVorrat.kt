package com.example.lebensmittelverwaltung.data.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable
import java.text.DateFormat


@Entity(tableName = "vorrat_produkt")
data class ProduktVorrat(
    @ColumnInfo(name = "vprodukt_name")
    var name :String,
    @ColumnInfo(name = "vprodukt_anzahl")
    var anzahl : Int,
    @ColumnInfo(name = "vprodukt_datum")
    var datum : String?,
) : Serializable {
    @PrimaryKey(autoGenerate = true)
    var id : Int? = null

}