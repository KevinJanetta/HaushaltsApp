package com.example.lebensmittelverwaltung.data.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.lebensmittelverwaltung.R
import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.ui.einkaufsliste.ViewModel
import kotlinx.android.synthetic.main.produkt_einkaufsliste.view.*

class ProduktAdapter (
    var items : List<Produkt>,
    private val viewModel : ViewModel,
        ) : RecyclerView.Adapter<ProduktAdapter.EinkaufsViewHolder>(){

    private var listener: ((item: Produkt) -> Unit)? = null

    fun setOnItemClickListener(listener: (item: Produkt) -> Unit) {
        this.listener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EinkaufsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.produkt_einkaufsliste, parent, false)
        return EinkaufsViewHolder(view)
    }

    override fun onBindViewHolder(holder: EinkaufsViewHolder, position: Int) {
        val curProdukt = items[position]

        holder.itemView.tvEinkaeufeNameEinkauf.text = curProdukt.name
        holder.itemView.tvPreisEinkauf.text = "${curProdukt.anzahl}"


        holder.itemView.ivdelete.setOnClickListener {
            viewModel.delete(curProdukt)
        }

        holder.itemView.ivbought.setOnClickListener {
            listener?.invoke(curProdukt)

        }


    }


    override fun getItemCount(): Int {
        return items.size
    }



    inner class EinkaufsViewHolder (itemview : View) : RecyclerView.ViewHolder(itemview)




}
