package com.example.lebensmittelverwaltung.ui.einkaufsliste.vorratsliste

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.lebensmittelverwaltung.EinkaeufeActivity
import com.example.lebensmittelverwaltung.data.adapter.ProduktVorratAdapter
import com.example.lebensmittelverwaltung.R
import com.example.lebensmittelverwaltung.data.db.EinkaufDatenbank
import com.example.lebensmittelverwaltung.data.db.entities.Produkt
import com.example.lebensmittelverwaltung.data.db.entities.ProduktVorrat
import com.example.lebensmittelverwaltung.data.reporsitories.Repository
import com.example.lebensmittelverwaltung.ui.einkaufsliste.AddDialogListener
import com.example.lebensmittelverwaltung.ui.einkaufsliste.ViewModel
import com.example.lebensmittelverwaltung.ui.einkaufsliste.ViewModelFactory
import com.example.lebensmittelverwaltung.ui.einkaufsliste.EinkaufslisteActivity
import kotlinx.android.synthetic.main.activity_einkaufsliste.*

class VorratslisteActivity : AppCompatActivity(){



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vorratsliste)



        val database = EinkaufDatenbank(this)
        val repository = Repository(database)
        val factory = ViewModelFactory(repository)
        //val factory2 = EinkaufsViewModelFactory(repository)


        val viewModel = ViewModelProviders.of(this, factory).get(ViewModel::class.java)
        //val viewModel2 =ViewModelProviders.of(this, factory2).get(EinkaufsViewModel::class.java)

        val adapter = ProduktVorratAdapter(listOf(), viewModel)


        rvEinkaeufeListe.layoutManager = LinearLayoutManager(this)
        rvEinkaeufeListe.adapter = adapter

        viewModel.getAllProdukteVorratsliste().observe(this, Observer {
            adapter.items = it
            adapter.notifyDataSetChanged()
        })

        val produkt = intent.getSerializableExtra("EXTRA_PRODUKT") as? ProduktVorrat
        if(produkt != null) {
            viewModel.upsertVorrat(produkt)
        }

        btnNeuerEinkauf.setOnClickListener {
            VorratProduktHinzufuegenDialog(this,
                object : AddDialogListener {
                    override fun onAddButtonClicked(produkt: Produkt) {
                        TODO("Not yet implemented")
                    }

                    override fun onAddButtonClickedEinkauf(name: String) {
                    }

                    override fun onAddButtonClickedVorrat(produktVorrat: ProduktVorrat) {
                    viewModel.upsertVorrat(produktVorrat)
                }
            }).show()
        }




        btnEinkaufsliste.setOnClickListener {
            Intent(this, EinkaufslisteActivity::class.java).also {
                startActivity(it)
            }
        }




        btnEinkaeufe.setOnClickListener {
            Intent(this, EinkaeufeActivity::class.java).also {
                startActivity(it)
            }
        }

    }
}